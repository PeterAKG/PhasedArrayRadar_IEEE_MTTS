/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file         stm32g4xx_hal_msp.c
  * @brief        This file provides code for the MSP Initialization
  *               and de-Initialization codes.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */
extern DMA_HandleTypeDef hdma_adc2;

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN Define */

/* USER CODE END Define */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN Macro */

/* USER CODE END Macro */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* External functions --------------------------------------------------------*/
/* USER CODE BEGIN ExternalFunctions */

/* USER CODE END ExternalFunctions */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);
                                                                                                    /**
  * Initializes the Global MSP.
  */
void HAL_MspInit(void)
{

  /* USER CODE BEGIN MspInit 0 */

  /* USER CODE END MspInit 0 */

  __HAL_RCC_SYSCFG_CLK_ENABLE();
  __HAL_RCC_PWR_CLK_ENABLE();

  /* System interrupt init*/

  /** Disable the internal Pull-Up in Dead Battery pins of UCPD peripheral
  */
  HAL_PWREx_DisableUCPDDeadBattery();

  /* USER CODE BEGIN MspInit 1 */

  /* USER CODE END MspInit 1 */
}

static uint32_t HAL_RCC_ADC345_CLK_ENABLED=0;

/**
  * @brief ADC MSP Initialization
  * This function configures the hardware resources used in this example
  * @param hadc: ADC handle pointer
  * @retval None
  */
void HAL_ADC_MspInit(ADC_HandleTypeDef* hadc)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};
  if(hadc->Instance==ADC2)
  {
    /* USER CODE BEGIN ADC2_MspInit 0 */

    /* USER CODE END ADC2_MspInit 0 */

  /** Initializes the peripherals clocks
  */
    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC12;
    PeriphClkInit.Adc12ClockSelection = RCC_ADC12CLKSOURCE_SYSCLK;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
    {
      Error_Handler();
    }

    /* Peripheral clock enable */
    __HAL_RCC_ADC12_CLK_ENABLE();

    __HAL_RCC_GPIOF_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    /**ADC2 GPIO Configuration
    PF1-OSC_OUT     ------> ADC2_IN10
    PC0     ------> ADC2_IN6
    PC1     ------> ADC2_IN7
    PC2     ------> ADC2_IN8
    PC3     ------> ADC2_IN9
    PA5     ------> ADC2_IN13
    PA6     ------> ADC2_IN3
    PA7     ------> ADC2_IN4
    PC4     ------> ADC2_IN5
    PC5     ------> ADC2_IN11
    PB2     ------> ADC2_IN12
    */
    GPIO_InitStruct.Pin = ADC2_IN10_PFC_AC_V_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(ADC2_IN10_PFC_AC_V_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |M2_TEMP_ID_ADC2_IN5_Pin|PFC_AC_ZC_ADC2_IN11_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = M2_RES_EX_DAC1_OUT2_Pin|M3_TEMP_ID_ADC2IN3_Pin|GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_2;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* ADC2 DMA Init */
    /* ADC2 Init */
    hdma_adc2.Instance = DMA1_Channel1;
    hdma_adc2.Init.Request = DMA_REQUEST_ADC2;
    hdma_adc2.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc2.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc2.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc2.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_adc2.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_adc2.Init.Mode = DMA_CIRCULAR;
    hdma_adc2.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_adc2) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(hadc,DMA_Handle,hdma_adc2);

    /* ADC2 interrupt Init */
    HAL_NVIC_SetPriority(ADC1_2_IRQn, 1, 0);
    HAL_NVIC_EnableIRQ(ADC1_2_IRQn);
    /* USER CODE BEGIN ADC2_MspInit 1 */

    /* USER CODE END ADC2_MspInit 1 */
  }
  else if(hadc->Instance==ADC3)
  {
    /* USER CODE BEGIN ADC3_MspInit 0 */

    /* USER CODE END ADC3_MspInit 0 */

  /** Initializes the peripherals clocks
  */
    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC345;
    PeriphClkInit.Adc345ClockSelection = RCC_ADC345CLKSOURCE_SYSCLK;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
    {
      Error_Handler();
    }

    /* Peripheral clock enable */
    HAL_RCC_ADC345_CLK_ENABLED++;
    if(HAL_RCC_ADC345_CLK_ENABLED==1){
      __HAL_RCC_ADC345_CLK_ENABLE();
    }

    __HAL_RCC_GPIOE_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    /**ADC3 GPIO Configuration
    PE12     ------> ADC3_IN16
    PB13     ------> ADC3_IN5
    PD10     ------> ADC3_IN7
    PD11     ------> ADC3_IN8
    PD12     ------> ADC3_IN9
    PD13     ------> ADC3_IN10
    PD14     ------> ADC3_IN11
    */
    GPIO_InitStruct.Pin = M1_VOLT_V_ADC345_IN16_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(M1_VOLT_V_ADC345_IN16_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = M1_VBUS_ADC3_IN5_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(M1_VBUS_ADC3_IN5_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = M1_VOLT_U_ADC345_IN7_Pin|M1_CURR_U_ADC345_IN8_Pin|M1_CURR_V_ADC345_IN9_Pin|M1_VOLT_W_ADC345_IN10_Pin
                          |M1_CURR_W_ADC345_IN11_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    /* USER CODE BEGIN ADC3_MspInit 1 */

    /* USER CODE END ADC3_MspInit 1 */
  }
  else if(hadc->Instance==ADC4)
  {
    /* USER CODE BEGIN ADC4_MspInit 0 */

    /* USER CODE END ADC4_MspInit 0 */

  /** Initializes the peripherals clocks
  */
    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC345;
    PeriphClkInit.Adc345ClockSelection = RCC_ADC345CLKSOURCE_SYSCLK;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
    {
      Error_Handler();
    }

    /* Peripheral clock enable */
    HAL_RCC_ADC345_CLK_ENABLED++;
    if(HAL_RCC_ADC345_CLK_ENABLED==1){
      __HAL_RCC_ADC345_CLK_ENABLE();
    }

    __HAL_RCC_GPIOE_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    /**ADC4 GPIO Configuration
    PE12     ------> ADC4_IN16
    PE14     ------> ADC4_IN1
    PE15     ------> ADC4_IN2
    PD8     ------> ADC4_IN12
    PD9     ------> ADC4_IN13
    PD10     ------> ADC4_IN7
    PD11     ------> ADC4_IN8
    PD12     ------> ADC4_IN9
    PD13     ------> ADC4_IN10
    PD14     ------> ADC4_IN11
    */
    GPIO_InitStruct.Pin = M1_VOLT_V_ADC345_IN16_Pin|ADC4_IN1_MORPHO_Pin|M1_TEMP_ID_ADC4_IN2_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = ADC45_IN12_PFC_Current1_Pin|ADC45_IN13_PFC_Current2_Pin|M1_VOLT_U_ADC345_IN7_Pin|M1_CURR_U_ADC345_IN8_Pin
                          |M1_CURR_V_ADC345_IN9_Pin|M1_VOLT_W_ADC345_IN10_Pin|M1_CURR_W_ADC345_IN11_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    /* USER CODE BEGIN ADC4_MspInit 1 */

    /* USER CODE END ADC4_MspInit 1 */
  }

}

/**
  * @brief ADC MSP De-Initialization
  * This function freeze the hardware resources used in this example
  * @param hadc: ADC handle pointer
  * @retval None
  */
void HAL_ADC_MspDeInit(ADC_HandleTypeDef* hadc)
{
  if(hadc->Instance==ADC2)
  {
    /* USER CODE BEGIN ADC2_MspDeInit 0 */

    /* USER CODE END ADC2_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_ADC12_CLK_DISABLE();

    /**ADC2 GPIO Configuration
    PF1-OSC_OUT     ------> ADC2_IN10
    PC0     ------> ADC2_IN6
    PC1     ------> ADC2_IN7
    PC2     ------> ADC2_IN8
    PC3     ------> ADC2_IN9
    PA5     ------> ADC2_IN13
    PA6     ------> ADC2_IN3
    PA7     ------> ADC2_IN4
    PC4     ------> ADC2_IN5
    PC5     ------> ADC2_IN11
    PB2     ------> ADC2_IN12
    */
    HAL_GPIO_DeInit(ADC2_IN10_PFC_AC_V_GPIO_Port, ADC2_IN10_PFC_AC_V_Pin);

    HAL_GPIO_DeInit(GPIOC, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |M2_TEMP_ID_ADC2_IN5_Pin|PFC_AC_ZC_ADC2_IN11_Pin);

    HAL_GPIO_DeInit(GPIOA, M2_RES_EX_DAC1_OUT2_Pin|M3_TEMP_ID_ADC2IN3_Pin|GPIO_PIN_7);

    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_2);

    /* ADC2 DMA DeInit */
    HAL_DMA_DeInit(hadc->DMA_Handle);

    /* ADC2 interrupt DeInit */
    HAL_NVIC_DisableIRQ(ADC1_2_IRQn);
    /* USER CODE BEGIN ADC2_MspDeInit 1 */

    /* USER CODE END ADC2_MspDeInit 1 */
  }
  else if(hadc->Instance==ADC3)
  {
    /* USER CODE BEGIN ADC3_MspDeInit 0 */

    /* USER CODE END ADC3_MspDeInit 0 */
    /* Peripheral clock disable */
    HAL_RCC_ADC345_CLK_ENABLED--;
    if(HAL_RCC_ADC345_CLK_ENABLED==0){
      __HAL_RCC_ADC345_CLK_DISABLE();
    }

    /**ADC3 GPIO Configuration
    PE12     ------> ADC3_IN16
    PB13     ------> ADC3_IN5
    PD10     ------> ADC3_IN7
    PD11     ------> ADC3_IN8
    PD12     ------> ADC3_IN9
    PD13     ------> ADC3_IN10
    PD14     ------> ADC3_IN11
    */
    HAL_GPIO_DeInit(M1_VOLT_V_ADC345_IN16_GPIO_Port, M1_VOLT_V_ADC345_IN16_Pin);

    HAL_GPIO_DeInit(M1_VBUS_ADC3_IN5_GPIO_Port, M1_VBUS_ADC3_IN5_Pin);

    HAL_GPIO_DeInit(GPIOD, M1_VOLT_U_ADC345_IN7_Pin|M1_CURR_U_ADC345_IN8_Pin|M1_CURR_V_ADC345_IN9_Pin|M1_VOLT_W_ADC345_IN10_Pin
                          |M1_CURR_W_ADC345_IN11_Pin);

    /* USER CODE BEGIN ADC3_MspDeInit 1 */

    /* USER CODE END ADC3_MspDeInit 1 */
  }
  else if(hadc->Instance==ADC4)
  {
    /* USER CODE BEGIN ADC4_MspDeInit 0 */

    /* USER CODE END ADC4_MspDeInit 0 */
    /* Peripheral clock disable */
    HAL_RCC_ADC345_CLK_ENABLED--;
    if(HAL_RCC_ADC345_CLK_ENABLED==0){
      __HAL_RCC_ADC345_CLK_DISABLE();
    }

    /**ADC4 GPIO Configuration
    PE12     ------> ADC4_IN16
    PE14     ------> ADC4_IN1
    PE15     ------> ADC4_IN2
    PD8     ------> ADC4_IN12
    PD9     ------> ADC4_IN13
    PD10     ------> ADC4_IN7
    PD11     ------> ADC4_IN8
    PD12     ------> ADC4_IN9
    PD13     ------> ADC4_IN10
    PD14     ------> ADC4_IN11
    */
    HAL_GPIO_DeInit(GPIOE, M1_VOLT_V_ADC345_IN16_Pin|ADC4_IN1_MORPHO_Pin|M1_TEMP_ID_ADC4_IN2_Pin);

    HAL_GPIO_DeInit(GPIOD, ADC45_IN12_PFC_Current1_Pin|ADC45_IN13_PFC_Current2_Pin|M1_VOLT_U_ADC345_IN7_Pin|M1_CURR_U_ADC345_IN8_Pin
                          |M1_CURR_V_ADC345_IN9_Pin|M1_VOLT_W_ADC345_IN10_Pin|M1_CURR_W_ADC345_IN11_Pin);

    /* USER CODE BEGIN ADC4_MspDeInit 1 */

    /* USER CODE END ADC4_MspDeInit 1 */
  }

}

/**
  * @brief DAC MSP Initialization
  * This function configures the hardware resources used in this example
  * @param hdac: DAC handle pointer
  * @retval None
  */
void HAL_DAC_MspInit(DAC_HandleTypeDef* hdac)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(hdac->Instance==DAC1)
  {
    /* USER CODE BEGIN DAC1_MspInit 0 */

    /* USER CODE END DAC1_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_DAC1_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**DAC1 GPIO Configuration
    PA4     ------> DAC1_OUT1
    PA5     ------> DAC1_OUT2
    */
    GPIO_InitStruct.Pin = M1_RES_EX_DAC1_OUT1_Pin|M2_RES_EX_DAC1_OUT2_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* USER CODE BEGIN DAC1_MspInit 1 */

    /* USER CODE END DAC1_MspInit 1 */

  }

}

/**
  * @brief DAC MSP De-Initialization
  * This function freeze the hardware resources used in this example
  * @param hdac: DAC handle pointer
  * @retval None
  */
void HAL_DAC_MspDeInit(DAC_HandleTypeDef* hdac)
{
  if(hdac->Instance==DAC1)
  {
    /* USER CODE BEGIN DAC1_MspDeInit 0 */

    /* USER CODE END DAC1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_DAC1_CLK_DISABLE();

    /**DAC1 GPIO Configuration
    PA4     ------> DAC1_OUT1
    PA5     ------> DAC1_OUT2
    */
    HAL_GPIO_DeInit(GPIOA, M1_RES_EX_DAC1_OUT1_Pin|M2_RES_EX_DAC1_OUT2_Pin);

    /* USER CODE BEGIN DAC1_MspDeInit 1 */

    /* USER CODE END DAC1_MspDeInit 1 */
  }

}

/**
  * @brief OPAMP MSP Initialization
  * This function configures the hardware resources used in this example
  * @param hopamp: OPAMP handle pointer
  * @retval None
  */
void HAL_OPAMP_MspInit(OPAMP_HandleTypeDef* hopamp)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(hopamp->Instance==OPAMP3)
  {
    /* USER CODE BEGIN OPAMP3_MspInit 0 */

    /* USER CODE END OPAMP3_MspInit 0 */

    __HAL_RCC_GPIOB_CLK_ENABLE();
    /**OPAMP3 GPIO Configuration
    PB0     ------> OPAMP3_VINP
    PB1     ------> OPAMP3_VOUT
    PB2     ------> OPAMP3_VINM
    */
    GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* USER CODE BEGIN OPAMP3_MspInit 1 */

    /* USER CODE END OPAMP3_MspInit 1 */
  }
  else if(hopamp->Instance==OPAMP4)
  {
    /* USER CODE BEGIN OPAMP4_MspInit 0 */

    /* USER CODE END OPAMP4_MspInit 0 */

    __HAL_RCC_GPIOB_CLK_ENABLE();
    /**OPAMP4 GPIO Configuration
    PB10     ------> OPAMP4_VINM
    PB11     ------> OPAMP4_VINP
    PB12     ------> OPAMP4_VOUT
    */
    GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* USER CODE BEGIN OPAMP4_MspInit 1 */

    /* USER CODE END OPAMP4_MspInit 1 */
  }
  else if(hopamp->Instance==OPAMP5)
  {
    /* USER CODE BEGIN OPAMP5_MspInit 0 */

    /* USER CODE END OPAMP5_MspInit 0 */

    __HAL_RCC_GPIOB_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**OPAMP5 GPIO Configuration
    PB14     ------> OPAMP5_VINP
    PB15     ------> OPAMP5_VINM
    PA8     ------> OPAMP5_VOUT
    */
    GPIO_InitStruct.Pin = GPIO_PIN_14|GPIO_PIN_15;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_8;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* USER CODE BEGIN OPAMP5_MspInit 1 */

    /* USER CODE END OPAMP5_MspInit 1 */
  }

}

/**
  * @brief OPAMP MSP De-Initialization
  * This function freeze the hardware resources used in this example
  * @param hopamp: OPAMP handle pointer
  * @retval None
  */
void HAL_OPAMP_MspDeInit(OPAMP_HandleTypeDef* hopamp)
{
  if(hopamp->Instance==OPAMP3)
  {
    /* USER CODE BEGIN OPAMP3_MspDeInit 0 */

    /* USER CODE END OPAMP3_MspDeInit 0 */

    /**OPAMP3 GPIO Configuration
    PB0     ------> OPAMP3_VINP
    PB1     ------> OPAMP3_VOUT
    PB2     ------> OPAMP3_VINM
    */
    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2);

    /* USER CODE BEGIN OPAMP3_MspDeInit 1 */

    /* USER CODE END OPAMP3_MspDeInit 1 */
  }
  else if(hopamp->Instance==OPAMP4)
  {
    /* USER CODE BEGIN OPAMP4_MspDeInit 0 */

    /* USER CODE END OPAMP4_MspDeInit 0 */

    /**OPAMP4 GPIO Configuration
    PB10     ------> OPAMP4_VINM
    PB11     ------> OPAMP4_VINP
    PB12     ------> OPAMP4_VOUT
    */
    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12);

    /* USER CODE BEGIN OPAMP4_MspDeInit 1 */

    /* USER CODE END OPAMP4_MspDeInit 1 */
  }
  else if(hopamp->Instance==OPAMP5)
  {
    /* USER CODE BEGIN OPAMP5_MspDeInit 0 */

    /* USER CODE END OPAMP5_MspDeInit 0 */

    /**OPAMP5 GPIO Configuration
    PB14     ------> OPAMP5_VINP
    PB15     ------> OPAMP5_VINM
    PA8     ------> OPAMP5_VOUT
    */
    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_14|GPIO_PIN_15);

    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_8);

    /* USER CODE BEGIN OPAMP5_MspDeInit 1 */

    /* USER CODE END OPAMP5_MspDeInit 1 */
  }

}

/**
  * @brief SPI MSP Initialization
  * This function configures the hardware resources used in this example
  * @param hspi: SPI handle pointer
  * @retval None
  */
void HAL_SPI_MspInit(SPI_HandleTypeDef* hspi)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(hspi->Instance==SPI1)
  {
    /* USER CODE BEGIN SPI1_MspInit 0 */

    /* USER CODE END SPI1_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_SPI1_CLK_ENABLE();

    __HAL_RCC_GPIOG_CLK_ENABLE();
    /**SPI1 GPIO Configuration
    PG2     ------> SPI1_SCK
    PG3     ------> SPI1_MISO
    PG4     ------> SPI1_MOSI
    PG5     ------> SPI1_NSS
    */
    GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF5_SPI1;
    HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

    /* USER CODE BEGIN SPI1_MspInit 1 */

    /* USER CODE END SPI1_MspInit 1 */

  }

}

/**
  * @brief SPI MSP De-Initialization
  * This function freeze the hardware resources used in this example
  * @param hspi: SPI handle pointer
  * @retval None
  */
void HAL_SPI_MspDeInit(SPI_HandleTypeDef* hspi)
{
  if(hspi->Instance==SPI1)
  {
    /* USER CODE BEGIN SPI1_MspDeInit 0 */

    /* USER CODE END SPI1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_SPI1_CLK_DISABLE();

    /**SPI1 GPIO Configuration
    PG2     ------> SPI1_SCK
    PG3     ------> SPI1_MISO
    PG4     ------> SPI1_MOSI
    PG5     ------> SPI1_NSS
    */
    HAL_GPIO_DeInit(GPIOG, GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5);

    /* USER CODE BEGIN SPI1_MspDeInit 1 */

    /* USER CODE END SPI1_MspDeInit 1 */
  }

}

/**
  * @brief TIM_Base MSP Initialization
  * This function configures the hardware resources used in this example
  * @param htim_base: TIM_Base handle pointer
  * @retval None
  */
void HAL_TIM_Base_MspInit(TIM_HandleTypeDef* htim_base)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(htim_base->Instance==TIM1)
  {
    /* USER CODE BEGIN TIM1_MspInit 0 */

    /* USER CODE END TIM1_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_TIM1_CLK_ENABLE();

    __HAL_RCC_GPIOE_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**TIM1 GPIO Configuration
    PE9     ------> TIM1_CH1
    PE11     ------> TIM1_CH2
    PA11     ------> TIM1_BKIN2
    PA15     ------> TIM1_BKIN
    */
    GPIO_InitStruct.Pin = M2_PWM_UH_TIM1_CH1_Pin|M2_PWM_VH_TIM1_CH2_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM1;
    HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = M2_TIM1_BKIN2_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF12_TIM1_COMP1;
    HAL_GPIO_Init(M2_TIM1_BKIN2_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_15;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF9_TIM1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* USER CODE BEGIN TIM1_MspInit 1 */

    /* USER CODE END TIM1_MspInit 1 */
  }
  else if(htim_base->Instance==TIM3)
  {
    /* USER CODE BEGIN TIM3_MspInit 0 */

    /* USER CODE END TIM3_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_TIM3_CLK_ENABLE();

    __HAL_RCC_GPIOE_CLK_ENABLE();
    /**TIM3 GPIO Configuration
    PE2     ------> TIM3_CH1
    PE3     ------> TIM3_CH2
    PE4     ------> TIM3_CH3
    */
    GPIO_InitStruct.Pin = M1_HALL_H1_TIM3_CH1_Pin|M1_HALL_H2_TIM3_CH2_Pin|M1_HALL_H3_TIM3_CH3_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM3;
    HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

    /* USER CODE BEGIN TIM3_MspInit 1 */

    /* USER CODE END TIM3_MspInit 1 */
  }
  else if(htim_base->Instance==TIM4)
  {
    /* USER CODE BEGIN TIM4_MspInit 0 */

    /* USER CODE END TIM4_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_TIM4_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    /**TIM4 GPIO Configuration
    PA12     ------> TIM4_CH2
    PB6     ------> TIM4_CH1
    PB8-BOOT0     ------> TIM4_CH3
    */
    GPIO_InitStruct.Pin = M2_HALL_H2_TIM4_CH2_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF10_TIM4;
    HAL_GPIO_Init(M2_HALL_H2_TIM4_CH2_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = M2_HALL_H1_TIM4_CH1_Pin|M2_HALL_H3_TIM4_CH3_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM4;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* USER CODE BEGIN TIM4_MspInit 1 */

    /* USER CODE END TIM4_MspInit 1 */
  }
  else if(htim_base->Instance==TIM8)
  {
    /* USER CODE BEGIN TIM8_MspInit 0 */

    /* USER CODE END TIM8_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_TIM8_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOD_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    /**TIM8 GPIO Configuration
    PA0     ------> TIM8_ETR
    PD1     ------> TIM8_BKIN2
    PB7     ------> TIM8_BKIN
    */
    GPIO_InitStruct.Pin = M1_TIM8_ETR_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF10_TIM8;
    HAL_GPIO_Init(M1_TIM8_ETR_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = M1_TIM8_BKIN2_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF6_TIM8;
    HAL_GPIO_Init(M1_TIM8_BKIN2_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = M1_TIM8_BKIN_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF5_TIM8;
    HAL_GPIO_Init(M1_TIM8_BKIN_GPIO_Port, &GPIO_InitStruct);

    /* USER CODE BEGIN TIM8_MspInit 1 */

    /* USER CODE END TIM8_MspInit 1 */
  }
  else if(htim_base->Instance==TIM16)
  {
    /* USER CODE BEGIN TIM16_MspInit 0 */

    /* USER CODE END TIM16_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_TIM16_CLK_ENABLE();

    __HAL_RCC_GPIOB_CLK_ENABLE();
    /**TIM16 GPIO Configuration
    PB5     ------> TIM16_BKIN
    */
    GPIO_InitStruct.Pin = PFC_TIM16_BKIN_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF1_TIM16;
    HAL_GPIO_Init(PFC_TIM16_BKIN_GPIO_Port, &GPIO_InitStruct);

    /* USER CODE BEGIN TIM16_MspInit 1 */

    /* USER CODE END TIM16_MspInit 1 */
  }
  else if(htim_base->Instance==TIM17)
  {
    /* USER CODE BEGIN TIM17_MspInit 0 */

    /* USER CODE END TIM17_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_TIM17_CLK_ENABLE();

    __HAL_RCC_GPIOB_CLK_ENABLE();
    /**TIM17 GPIO Configuration
    PB4     ------> TIM17_BKIN
    */
    GPIO_InitStruct.Pin = PFC_TIM17_BKIN_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF10_TIM17;
    HAL_GPIO_Init(PFC_TIM17_BKIN_GPIO_Port, &GPIO_InitStruct);

    /* USER CODE BEGIN TIM17_MspInit 1 */

    /* USER CODE END TIM17_MspInit 1 */
  }
  else if(htim_base->Instance==TIM20)
  {
    /* USER CODE BEGIN TIM20_MspInit 0 */

    /* USER CODE END TIM20_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_TIM20_CLK_ENABLE();

    __HAL_RCC_GPIOF_CLK_ENABLE();
    /**TIM20 GPIO Configuration
    PF9     ------> TIM20_BKIN
    PF10     ------> TIM20_BKIN2
    PF12     ------> TIM20_CH1
    */
    GPIO_InitStruct.Pin = M3_TIM20_BKIN_Pin|M3_TIM20_BKIN2_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM20;
    HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = M3_PWM_UH_TIM20_CH1_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM20;
    HAL_GPIO_Init(M3_PWM_UH_TIM20_CH1_GPIO_Port, &GPIO_InitStruct);

    /* USER CODE BEGIN TIM20_MspInit 1 */

    /* USER CODE END TIM20_MspInit 1 */
  }

}

/**
  * @brief TIM_IC MSP Initialization
  * This function configures the hardware resources used in this example
  * @param htim_ic: TIM_IC handle pointer
  * @retval None
  */
void HAL_TIM_IC_MspInit(TIM_HandleTypeDef* htim_ic)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(htim_ic->Instance==TIM2)
  {
    /* USER CODE BEGIN TIM2_MspInit 0 */

    /* USER CODE END TIM2_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_TIM2_CLK_ENABLE();

    __HAL_RCC_GPIOD_CLK_ENABLE();
    /**TIM2 GPIO Configuration
    PD3     ------> TIM2_CH1
    PD4     ------> TIM2_CH2
    PD7     ------> TIM2_CH3
    */
    GPIO_InitStruct.Pin = M2_ENCA_TIM2_CH1_Pin|M2_ENCB_TIM2_CH2_Pin|M2_ENCZ_TIM2_CH3_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM2;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    /* USER CODE BEGIN TIM2_MspInit 1 */

    /* USER CODE END TIM2_MspInit 1 */
  }
  else if(htim_ic->Instance==TIM5)
  {
    /* USER CODE BEGIN TIM5_MspInit 0 */

    /* USER CODE END TIM5_MspInit 0 */
    /* Peripheral clock enable */
    __HAL_RCC_TIM5_CLK_ENABLE();

    __HAL_RCC_GPIOF_CLK_ENABLE();
    /**TIM5 GPIO Configuration
    PF7     ------> TIM5_CH2
    PF8     ------> TIM5_CH3
    PF6     ------> TIM5_CH1
    */
    GPIO_InitStruct.Pin = M1_ENCB_TIM5_CH2_Pin|M1_ENCZ_TIM5_CH3_Pin|M1_ENCA_TIM5_CH1_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF6_TIM5;
    HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

    /* USER CODE BEGIN TIM5_MspInit 1 */

    /* USER CODE END TIM5_MspInit 1 */
  }

}

void HAL_TIM_MspPostInit(TIM_HandleTypeDef* htim)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(htim->Instance==TIM1)
  {
    /* USER CODE BEGIN TIM1_MspPostInit 0 */

    /* USER CODE END TIM1_MspPostInit 0 */
    __HAL_RCC_GPIOE_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
    /**TIM1 GPIO Configuration
    PE13     ------> TIM1_CH3
    PB9     ------> TIM1_CH3N
    */
    GPIO_InitStruct.Pin = M2_PWM_WL_TIM1_CH3_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM1;
    HAL_GPIO_Init(M2_PWM_WL_TIM1_CH3_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = M2_PWM_WL_TIM1_CH3N_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF12_TIM1_COMP1;
    HAL_GPIO_Init(M2_PWM_WL_TIM1_CH3N_GPIO_Port, &GPIO_InitStruct);

    /* USER CODE BEGIN TIM1_MspPostInit 1 */

    /* USER CODE END TIM1_MspPostInit 1 */
  }
  else if(htim->Instance==TIM8)
  {
    /* USER CODE BEGIN TIM8_MspPostInit 0 */

    /* USER CODE END TIM8_MspPostInit 0 */

    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**TIM8 GPIO Configuration
    PC6     ------> TIM8_CH1
    PC7     ------> TIM8_CH2
    PC8     ------> TIM8_CH3
    PC10     ------> TIM8_CH1N
    PC11     ------> TIM8_CH2N
    PC12     ------> TIM8_CH3N
    */
    GPIO_InitStruct.Pin = M1_PWM_UH_TIM8_CH1_Pin|M1_PWM_VH_TIM8_CH2_Pin|M1_PWM_WH_TIM8_CH3_Pin|M1_PWM_UL_TIM8_CH1N_Pin
                          |M1_PWM_VL_TIM8_CH2N_Pin|M1_PWM_WL_TIM8_CH3N_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF4_TIM8;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* USER CODE BEGIN TIM8_MspPostInit 1 */

    /* USER CODE END TIM8_MspPostInit 1 */
  }
  else if(htim->Instance==TIM16)
  {
    /* USER CODE BEGIN TIM16_MspPostInit 0 */

    /* USER CODE END TIM16_MspPostInit 0 */

    __HAL_RCC_GPIOE_CLK_ENABLE();
    /**TIM16 GPIO Configuration
    PE0     ------> TIM16_CH1
    */
    GPIO_InitStruct.Pin = PFC_PWM1_TIM16_CH1_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF4_TIM16;
    HAL_GPIO_Init(PFC_PWM1_TIM16_CH1_GPIO_Port, &GPIO_InitStruct);

    /* USER CODE BEGIN TIM16_MspPostInit 1 */

    /* USER CODE END TIM16_MspPostInit 1 */
  }
  else if(htim->Instance==TIM17)
  {
    /* USER CODE BEGIN TIM17_MspPostInit 0 */

    /* USER CODE END TIM17_MspPostInit 0 */

    __HAL_RCC_GPIOE_CLK_ENABLE();
    /**TIM17 GPIO Configuration
    PE1     ------> TIM17_CH1
    */
    GPIO_InitStruct.Pin = PFC_PWM2_TIM17_CH1_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF4_TIM17;
    HAL_GPIO_Init(PFC_PWM2_TIM17_CH1_GPIO_Port, &GPIO_InitStruct);

    /* USER CODE BEGIN TIM17_MspPostInit 1 */

    /* USER CODE END TIM17_MspPostInit 1 */
  }
  else if(htim->Instance==TIM20)
  {
    /* USER CODE BEGIN TIM20_MspPostInit 0 */

    /* USER CODE END TIM20_MspPostInit 0 */

    __HAL_RCC_GPIOE_CLK_ENABLE();
    __HAL_RCC_GPIOF_CLK_ENABLE();
    __HAL_RCC_GPIOG_CLK_ENABLE();
    /**TIM20 GPIO Configuration
    PE6     ------> TIM20_CH3N
    PF13     ------> TIM20_CH2
    PF14     ------> TIM20_CH3
    PG0     ------> TIM20_CH1N
    PG1     ------> TIM20_CH2N
    */
    GPIO_InitStruct.Pin = M3_PWM_WL_TIM20_CH3N_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF6_TIM20;
    HAL_GPIO_Init(M3_PWM_WL_TIM20_CH3N_GPIO_Port, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = M3_PWM_VH_TIM20_CH2_Pin|M3_PWM_WH_TIM20_CH3_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM20;
    HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = M3_PWM_UL_TIM20_CH1N_Pin|M3_PWM_VL_TIM20_CH2N_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM20;
    HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

    /* USER CODE BEGIN TIM20_MspPostInit 1 */

    /* USER CODE END TIM20_MspPostInit 1 */
  }

}
/**
  * @brief TIM_Base MSP De-Initialization
  * This function freeze the hardware resources used in this example
  * @param htim_base: TIM_Base handle pointer
  * @retval None
  */
void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef* htim_base)
{
  if(htim_base->Instance==TIM1)
  {
    /* USER CODE BEGIN TIM1_MspDeInit 0 */

    /* USER CODE END TIM1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_TIM1_CLK_DISABLE();

    /**TIM1 GPIO Configuration
    PE9     ------> TIM1_CH1
    PE11     ------> TIM1_CH2
    PE13     ------> TIM1_CH3
    PA11     ------> TIM1_BKIN2
    PA15     ------> TIM1_BKIN
    PB9     ------> TIM1_CH3N
    */
    HAL_GPIO_DeInit(GPIOE, M2_PWM_UH_TIM1_CH1_Pin|M2_PWM_VH_TIM1_CH2_Pin|M2_PWM_WL_TIM1_CH3_Pin);

    HAL_GPIO_DeInit(GPIOA, M2_TIM1_BKIN2_Pin|GPIO_PIN_15);

    HAL_GPIO_DeInit(M2_PWM_WL_TIM1_CH3N_GPIO_Port, M2_PWM_WL_TIM1_CH3N_Pin);

    /* USER CODE BEGIN TIM1_MspDeInit 1 */

    /* USER CODE END TIM1_MspDeInit 1 */
  }
  else if(htim_base->Instance==TIM3)
  {
    /* USER CODE BEGIN TIM3_MspDeInit 0 */

    /* USER CODE END TIM3_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_TIM3_CLK_DISABLE();

    /**TIM3 GPIO Configuration
    PE2     ------> TIM3_CH1
    PE3     ------> TIM3_CH2
    PE4     ------> TIM3_CH3
    */
    HAL_GPIO_DeInit(GPIOE, M1_HALL_H1_TIM3_CH1_Pin|M1_HALL_H2_TIM3_CH2_Pin|M1_HALL_H3_TIM3_CH3_Pin);

    /* USER CODE BEGIN TIM3_MspDeInit 1 */

    /* USER CODE END TIM3_MspDeInit 1 */
  }
  else if(htim_base->Instance==TIM4)
  {
    /* USER CODE BEGIN TIM4_MspDeInit 0 */

    /* USER CODE END TIM4_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_TIM4_CLK_DISABLE();

    /**TIM4 GPIO Configuration
    PA12     ------> TIM4_CH2
    PB6     ------> TIM4_CH1
    PB8-BOOT0     ------> TIM4_CH3
    */
    HAL_GPIO_DeInit(M2_HALL_H2_TIM4_CH2_GPIO_Port, M2_HALL_H2_TIM4_CH2_Pin);

    HAL_GPIO_DeInit(GPIOB, M2_HALL_H1_TIM4_CH1_Pin|M2_HALL_H3_TIM4_CH3_Pin);

    /* USER CODE BEGIN TIM4_MspDeInit 1 */

    /* USER CODE END TIM4_MspDeInit 1 */
  }
  else if(htim_base->Instance==TIM8)
  {
    /* USER CODE BEGIN TIM8_MspDeInit 0 */

    /* USER CODE END TIM8_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_TIM8_CLK_DISABLE();

    /**TIM8 GPIO Configuration
    PA0     ------> TIM8_ETR
    PC6     ------> TIM8_CH1
    PC7     ------> TIM8_CH2
    PC8     ------> TIM8_CH3
    PC10     ------> TIM8_CH1N
    PC11     ------> TIM8_CH2N
    PC12     ------> TIM8_CH3N
    PD1     ------> TIM8_BKIN2
    PB7     ------> TIM8_BKIN
    */
    HAL_GPIO_DeInit(M1_TIM8_ETR_GPIO_Port, M1_TIM8_ETR_Pin);

    HAL_GPIO_DeInit(GPIOC, M1_PWM_UH_TIM8_CH1_Pin|M1_PWM_VH_TIM8_CH2_Pin|M1_PWM_WH_TIM8_CH3_Pin|M1_PWM_UL_TIM8_CH1N_Pin
                          |M1_PWM_VL_TIM8_CH2N_Pin|M1_PWM_WL_TIM8_CH3N_Pin);

    HAL_GPIO_DeInit(M1_TIM8_BKIN2_GPIO_Port, M1_TIM8_BKIN2_Pin);

    HAL_GPIO_DeInit(M1_TIM8_BKIN_GPIO_Port, M1_TIM8_BKIN_Pin);

    /* USER CODE BEGIN TIM8_MspDeInit 1 */

    /* USER CODE END TIM8_MspDeInit 1 */
  }
  else if(htim_base->Instance==TIM16)
  {
    /* USER CODE BEGIN TIM16_MspDeInit 0 */

    /* USER CODE END TIM16_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_TIM16_CLK_DISABLE();

    /**TIM16 GPIO Configuration
    PB5     ------> TIM16_BKIN
    PE0     ------> TIM16_CH1
    */
    HAL_GPIO_DeInit(PFC_TIM16_BKIN_GPIO_Port, PFC_TIM16_BKIN_Pin);

    HAL_GPIO_DeInit(PFC_PWM1_TIM16_CH1_GPIO_Port, PFC_PWM1_TIM16_CH1_Pin);

    /* USER CODE BEGIN TIM16_MspDeInit 1 */

    /* USER CODE END TIM16_MspDeInit 1 */
  }
  else if(htim_base->Instance==TIM17)
  {
    /* USER CODE BEGIN TIM17_MspDeInit 0 */

    /* USER CODE END TIM17_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_TIM17_CLK_DISABLE();

    /**TIM17 GPIO Configuration
    PB4     ------> TIM17_BKIN
    PE1     ------> TIM17_CH1
    */
    HAL_GPIO_DeInit(PFC_TIM17_BKIN_GPIO_Port, PFC_TIM17_BKIN_Pin);

    HAL_GPIO_DeInit(PFC_PWM2_TIM17_CH1_GPIO_Port, PFC_PWM2_TIM17_CH1_Pin);

    /* USER CODE BEGIN TIM17_MspDeInit 1 */

    /* USER CODE END TIM17_MspDeInit 1 */
  }
  else if(htim_base->Instance==TIM20)
  {
    /* USER CODE BEGIN TIM20_MspDeInit 0 */

    /* USER CODE END TIM20_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_TIM20_CLK_DISABLE();

    /**TIM20 GPIO Configuration
    PE6     ------> TIM20_CH3N
    PF9     ------> TIM20_BKIN
    PF10     ------> TIM20_BKIN2
    PF12     ------> TIM20_CH1
    PF13     ------> TIM20_CH2
    PF14     ------> TIM20_CH3
    PG0     ------> TIM20_CH1N
    PG1     ------> TIM20_CH2N
    */
    HAL_GPIO_DeInit(M3_PWM_WL_TIM20_CH3N_GPIO_Port, M3_PWM_WL_TIM20_CH3N_Pin);

    HAL_GPIO_DeInit(GPIOF, M3_TIM20_BKIN_Pin|M3_TIM20_BKIN2_Pin|M3_PWM_UH_TIM20_CH1_Pin|M3_PWM_VH_TIM20_CH2_Pin
                          |M3_PWM_WH_TIM20_CH3_Pin);

    HAL_GPIO_DeInit(GPIOG, M3_PWM_UL_TIM20_CH1N_Pin|M3_PWM_VL_TIM20_CH2N_Pin);

    /* USER CODE BEGIN TIM20_MspDeInit 1 */

    /* USER CODE END TIM20_MspDeInit 1 */
  }

}

/**
  * @brief TIM_IC MSP De-Initialization
  * This function freeze the hardware resources used in this example
  * @param htim_ic: TIM_IC handle pointer
  * @retval None
  */
void HAL_TIM_IC_MspDeInit(TIM_HandleTypeDef* htim_ic)
{
  if(htim_ic->Instance==TIM2)
  {
    /* USER CODE BEGIN TIM2_MspDeInit 0 */

    /* USER CODE END TIM2_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_TIM2_CLK_DISABLE();

    /**TIM2 GPIO Configuration
    PD3     ------> TIM2_CH1
    PD4     ------> TIM2_CH2
    PD7     ------> TIM2_CH3
    */
    HAL_GPIO_DeInit(GPIOD, M2_ENCA_TIM2_CH1_Pin|M2_ENCB_TIM2_CH2_Pin|M2_ENCZ_TIM2_CH3_Pin);

    /* USER CODE BEGIN TIM2_MspDeInit 1 */

    /* USER CODE END TIM2_MspDeInit 1 */
  }
  else if(htim_ic->Instance==TIM5)
  {
    /* USER CODE BEGIN TIM5_MspDeInit 0 */

    /* USER CODE END TIM5_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_TIM5_CLK_DISABLE();

    /**TIM5 GPIO Configuration
    PF7     ------> TIM5_CH2
    PF8     ------> TIM5_CH3
    PF6     ------> TIM5_CH1
    */
    HAL_GPIO_DeInit(GPIOF, M1_ENCB_TIM5_CH2_Pin|M1_ENCZ_TIM5_CH3_Pin|M1_ENCA_TIM5_CH1_Pin);

    /* USER CODE BEGIN TIM5_MspDeInit 1 */

    /* USER CODE END TIM5_MspDeInit 1 */
  }

}

/**
  * @brief UART MSP Initialization
  * This function configures the hardware resources used in this example
  * @param huart: UART handle pointer
  * @retval None
  */
void HAL_UART_MspInit(UART_HandleTypeDef* huart)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};
  if(huart->Instance==USART1)
  {
    /* USER CODE BEGIN USART1_MspInit 0 */

    /* USER CODE END USART1_MspInit 0 */

  /** Initializes the peripherals clocks
  */
    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1;
    PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK2;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
    {
      Error_Handler();
    }

    /* Peripheral clock enable */
    __HAL_RCC_USART1_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOG_CLK_ENABLE();
    /**USART1 GPIO Configuration
    PA10     ------> USART1_RX
    PG9     ------> USART1_TX
    */
    GPIO_InitStruct.Pin = GPIO_PIN_10;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

    /* USER CODE BEGIN USART1_MspInit 1 */

    /* USER CODE END USART1_MspInit 1 */

  }

}

/**
  * @brief UART MSP De-Initialization
  * This function freeze the hardware resources used in this example
  * @param huart: UART handle pointer
  * @retval None
  */
void HAL_UART_MspDeInit(UART_HandleTypeDef* huart)
{
  if(huart->Instance==USART1)
  {
    /* USER CODE BEGIN USART1_MspDeInit 0 */

    /* USER CODE END USART1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_USART1_CLK_DISABLE();

    /**USART1 GPIO Configuration
    PA10     ------> USART1_RX
    PG9     ------> USART1_TX
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_10);

    HAL_GPIO_DeInit(GPIOG, GPIO_PIN_9);

    /* USER CODE BEGIN USART1_MspDeInit 1 */

    /* USER CODE END USART1_MspDeInit 1 */
  }

}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
